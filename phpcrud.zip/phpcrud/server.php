<?php
	session_start();
	$name = "";
	$sex = "";
	$hometown = "";
	$address = "";
	$class = "";
	$id = 0;
	$edit_state = false;

	// Connect to Database
	// Membuat varible koneksi
	// #1
	$db = mysqli_connect('localhost', 'root', '', 'crud');
	$dbh = new PDO ("mysql:host=localhost;dbname=crud", "root", "");
	// if save button is clicked
	if(isset($_POST['simpan'])) {
		$name = $_POST['name'];
		$address = $_POST['address'];
		$sex = $_POST['sex'];
		$hometown = $_POST['hometown'];
		$class = $_POST['class'];
		#2
		$query = "INSERT INTO info (name, address, sex, hometown, class) VALUES ('$name', '$address', '$sex', '$hometown', '$class')";

		mysqli_query($db, $query);
		$_SESSION['msg'] = "Address Saved";
		header('location: index.php');
	}

	if(isset($_POST['update'])){
	$class = mysql_real_escape_string($_POST['class']);
	$hometown = mysql_real_escape_string($_POST['hometown']);
	$sex = mysql_real_escape_string($_POST['sex']);
	$name = mysql_real_escape_string($_POST['name']);
	$address = mysql_real_escape_string($_POST['address']);
	$id = mysql_real_escape_string($_POST['id']);

	mysqli_query($db, "UPDATE info SET name = '$name', address='$address', sex ='$sex', hometown = '$hometown', class = '$class' WHERE id=$id");
	$_SESSION['msg'] = "Data Updated";
	header('location: index.php');
}

	if(isset($_GET['del'])) {
		$id = $_GET['del'];
		mysqli_query($db, "DELETE FROM info WHERE id=$id");
		$_SESSION['msg'] = "Data Deleted!";
		header('location: index.php');
	}

	$results = mysqli_query($db, "SELECT * FROM info");
?>
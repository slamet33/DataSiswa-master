<?php 
  include 'server.php';
    
    $response = array();
    $vsusername = $_POST['vsusername'];
    $vspassword = md5($_POST['vspassword']);   
         
        #Query the database to get the user details. 
        $leveldetails = mysqli_query($db, "SELECT * FROM tbl_user WHERE username = '$vsusername' and password = '$vspassword' "); 
        if (!$leveldetails) { 
	         echo 'Could not run query: ' . mysqli_error($db); 
           exit;
        } 
  
        #Get the first row of the results 
        $row = mysqli_fetch_row($leveldetails); 

        #Build the result array (Assign keys to the values) 
        $result_data = array
            (
                'id'        => $row[0],
                'nama'      => $row[1],
                'alamat'    => $row[2],
                'no_telp'   => $row[3],
                'jenkel'    => $row[4],
                'username'  => $row[5],
                'password'  => $row[6]
            );



	
        #Output the JSON data 
    if (mysqli_num_rows($leveldetails) > 0) {
      
      $response['result'] = "1";
      $response['msg'] = "Berhasil login!!";
      $response['user'] = $result_data;

    } else
    {
        $response['result'] = "0";
        $response['msg'] = "Gagal login!!";
    }
      echo json_encode($response);
?>
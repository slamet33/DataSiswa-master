<?php 
	include 'server.php';

	$response = array();
	$id = @$_POST['vsid'];

	$sql = "DELETE FROM info WHERE id='$id'";
	if(mysqli_query($db,$sql)){
	   $response["result"] = true;
       $response["msg"] = "data berhasil dihapus!!";
       echo json_encode($response);
		}else{
	   $response["result"] = false;
       $response["msg"] = "Gagal menghapus data";
		echo json_encode($response);
		}
		mysqli_close($db);
?>
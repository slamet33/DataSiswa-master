<?php include ('server.php');

// Statement ini digunakan hanya untuk menampilkan value didalam form	
	if(isset($_GET['edi'])) {
		$id = $_GET['edi'];
		$edit_state = true;
		$rec = mysqli_query($db, "SELECT * FROM info WHERE id=$id");
		$record = mysqli_fetch_array($rec);
		$class = $record['class'];
		$sex = $record['sex'];
		$hometown = $record['hometown'];
		$name = $record['name'];
		$address = $record['address'];
		$id = $record['id'];
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Latihan CRUD Using PHP</title>

	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php if (isset($_SESSION['msg'])): ?>
	<div class="msg">
		<?php
		echo $_SESSION['msg'];
		unset($_SESSION['msg']);
		?>
	</div>
<?php endif ?>
<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Address</th>
			<th>Sex</th>
			<th>HomeTown</th>
			<th>Class</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	<tbody>
		<?php while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['address']; ?></td>
			<td><?php echo $row['sex']; ?></td>
			<td><?php echo $row['hometown']; ?></td>
			<td><?php echo $row['class'];?></td>
			<td><a class="edt_btn" href="index.php?edi=<?php echo $row['id']; ?>">Edit</td>
			<td><a class="del_btn" href="index.php?del=<?php echo $row['id']; ?>">Delete</td>
		</tr>
		<?php } ?>
	</tbody>
</table>
<form method="post" action="server.php">
	<input type="hidden" name="id" value="<?php echo $id; ?>">
	<div class="input-group">
		<label>Name</label>
		<input type="text" name="name" value="<?php echo $name; ?>">
	</div>
	<div class="input-group">
		<label>Address</label>
		<input type="text" name="address" value="<?php echo $address; ?>">
	</div>
	<div class="input-group">
		<label>Sex</label>
		<input type="text" name="sex" value="<?php echo $sex; ?>">
	</div>
	<div class="input-group">
		<label>Home Town</label>
		<input type="text" name="hometown" value="<?php echo $hometown; ?>">
	</div>
	<div class="input-group">
		<label>Class</label>
		<input type="text" name="class" value="<?php echo $class; ?>">
	</div>
	<div class="input-grup">
		<?php if ($edit_state == false): ?>
			<button type="submit" name="simpan" class="btn">Save</button>
		<?php else: ?>
			<button type="submit" name="update" class="btn">Update</button>
		<?php endif ?>
	</div>
</form>
</body>
</html>
<?php
require_once('server.php');

if($_SERVER['REQUEST_METHOD']=='POST') {

  $response = array();
  //mendapatkan data
  $id = $_POST['vsid'];
  $name = $_POST['vsname'];
  $address = $_POST['vsaddress'];
  $sex = $_POST['vssex'];
  $hometown = $_POST['vshometown'];
  $class = $_POST['vsclass'];
  $image = $_POST['vsimage'];

  $sql = "UPDATE info SET name = '$name', address = '$address', sex = '$sex', hometown = '$hometown', class = '$class', image = '$image' WHERE id = '$id'";
  
  if(mysqli_query($db,$sql)) {
    $response ["pesan"]  = "Data Berhasil di Perbarui";
    $response ["sukses"] = true;
    echo json_encode($response);
  } else {
    $response ["pesan"]  = "Gagal Memperbarui Data";
    $response ["sukses"] = false;
    echo json_encode($response);
  }
  mysqli_close($db);
}
?>
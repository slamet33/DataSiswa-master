<?php 
include 'server.php';
	$response = array(); 
	
	
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		//checking the required parameters from the request 
			if (isset($_POST["vsjenkel"]) && isset($_POST["vsnama"])  && isset($_POST["vsalamat"])  && isset($_POST["vsnotelp"])&& isset($_POST["vsusername"]) && isset($_POST["vspassword"])) {
		
		$nama = $_POST['vsnama'];	
		$alamat = $_POST['vsalamat'];
		$jenkel = $_POST['vsjenkel'];
		$notelp = $_POST['vsnotelp'];
		$username = $_POST['vsusername'];
		$password = md5($_POST["vspassword"]);
	
 	$sql = "SELECT * FROM tbl_user WHERE username ='$username'";
   	$check = mysqli_fetch_array(mysqli_query($db,$sql));
   if(isset($check)){
     $response["result"] = 0;
     $response["msg"] = "oops! username sudah terdaftar!";
     echo json_encode($response);
   }else{
				//saving the file 
			//	move_uploaded_file($_FILES['image']['tmp_name'],$file_path);
				$sql = "INSERT INTO `tbl_user` ( `nama`,`alamat`,`no_telp`,`jenkel`,`username`,`password`) VALUES ('$nama', '$alamat', '$notelp', '$jenkel', '$username', '$password');";
				
				//adding the path and name to database 
				if(mysqli_query($db,$sql)){
				//		echo 'Setting berhasil';
		
		$response['result'] = "1";
        $response['msg'] = "Berhasil register!!";
      //  $response['user'] = $nama;
     
					//filling response array with values 
					// $response['error'] = false; 
					// $response['url'] = $file_url; 
					// $response['name'] = $name;
				}else{
		//	echo 'Terjadi kesalahan, ulangi lagi!';
		   $response['result'] = "0";
      				$response['msg'] = "Gagal register!!";
	
		}
			//displaying the response 
			echo json_encode($response);
			
			//closing the connection 
		//	mysqli_close($connection);
		// }else{
		// 	$response['error']=true;
		// 	$response['message']='Please choose a file';
		 }
	}
	}
	/*
		We are generating the file name 
		so this method will return a file name for the image to be upload 
	*/

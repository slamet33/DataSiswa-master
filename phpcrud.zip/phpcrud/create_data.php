<?php
	include 'server.php';

	$name = @$_POST['vsname'];
	$address = @$_POST['vsaddress'];
	$sex = @$_POST['vssex'];
	$hometown = @$_POST['vshometown'];
	$class = @$_POST['vsclass'];
	$image = @$_POST['vsimage'];

		if ($_SERVER['REQUEST_METHOD'] == "POST"){

			$sql = "INSERT INTO info (name, address, sex, hometown, class, image) VALUES ('$name', '$address', '$sex', '$hometown', '$class', '$image')";
						 if ($result = $db->query($sql)) {
							$json_response ["pesan"]  = "Data tersimpan";
							$json_response ["sukses"] = true;
							echo json_encode($json_response);
					 	} else{
							$json_response ["pesan"]  = "Gagal menyimpan data";
							$json_response ["sukses"] = false;
					 		echo json_encode($json_response);
					 	}
		
		} else {
			$json_response ["pesan"]  = "Request salah";
			$json_response ["sukses"] = false;
			echo json_encode($json_response);
		}
?>